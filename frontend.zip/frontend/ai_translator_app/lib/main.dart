import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI翻译助手',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const TranslatePage(),
    );
  }
}

class TranslatePage extends StatefulWidget {
  const TranslatePage({super.key});

  @override
  State<TranslatePage> createState() => _TranslatePageState();
}

class _TranslatePageState extends State<TranslatePage> {
  final TextEditingController _controller = TextEditingController();
  String _translation = '';
  List<String> _keywords = [];
  bool _loading = false;

  Future<void> _translate() async {
    if (_controller.text.isEmpty) return;

    setState(() {
      _loading = true;
      _translation = '';
      _keywords = [];
    });

    try {
      final response = await http.post(
        Uri.parse('http://127.0.0.1:8000/translate'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'text': _controller.text}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _translation = data['translation'] ?? '';
          _keywords = List<String>.from(data['keywords'] ?? []);
        });
      } else {
        setState(() {
          _translation = '翻译失败，状态码：${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        _translation = '请求失败：$e';
      });
    } finally {
      setState(() {
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI翻译助手')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _controller,
              maxLines: 3,
              decoration: const InputDecoration(
                hintText: '请输入中文...',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: _loading ? null : _translate,
              child: _loading
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('点击翻译'),
            ),
            const SizedBox(height: 20),
            if (_translation.isNotEmpty) ...[
              const Text('翻译结果：',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.grey[100],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(_translation, style: const TextStyle(fontSize: 16)),
              ),
            ],
            if (_keywords.isNotEmpty) ...[
              const SizedBox(height: 16),
              const Text('关键词：',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: _keywords
                    .map((k) => Chip(label: Text(k)))
                    .toList(),
              ),
            ],
          ],
        ),
      ),
    );
  }
}